#include "poly_obj.hpp"

#include <iostream>
#include <exception>

struct Base : public virtual_ctors<Base>
{
	Base() : value(0)
	{
	}

	virtual void print_stuff()
	{
		std::cout << "I'm a base with state " << value << std::endl;
	}

	virtual void set_value(int i)
	{
		value = i;
	}

	int value;
};

struct Derived : public virtual_ctors<Derived, Base>
{
	virtual void print_stuff()
	{
		std::cout << "I'm a derived with state " << value << std::endl;
	}
};

struct DerivedDerived : public virtual_ctors<DerivedDerived, Derived>
{
	virtual void print_stuff()
	{
		std::cout << "I'm a derived-derived with state " << value << std::endl;
	}
};

int main()
{
	try
	{
		poly_obj<Derived> b(boost::in_place<Derived>());
		b->set_value(42);

		poly_obj<Base> b2 = b;

		b->print_stuff();
		b2->print_stuff();

		b2->set_value(31);

		b->print_stuff();
		b2->print_stuff();

		poly_obj<Derived> b3 = dynamic_poly_cast<Derived>(b2);
		//poly_obj<DerivedDerived> b4 = dynamic_poly_cast<DerivedDerived>(b2); // throws
	}
	catch(const std::exception& e)
	{
		std::cout << "Standard exception occured: " << e.what() << std::endl;
	}
	catch(...)
	{
		std::cout << "Unknown exception occured." << std::endl;
	}
}
