#include <utility>
#include <new>

#include <boost/type_traits.hpp>
#include <boost/mpl/and.hpp>
#include <boost/utility/enable_if.hpp>

#include <boost/utility/in_place_factory.hpp>
#include <boost/utility/typed_in_place_factory.hpp>

#include <boost/version.hpp>

#if ((BOOST_VERSION / 100) % 1000) < 35

namespace boost {

class empty_in_place_factory : public in_place_factory_base
{
public:
	empty_in_place_factory()
	{
	}

	template<typename T>
	void apply(void* address) const
	{
		new(address) T;
	}
};

empty_in_place_factory in_place()
{
	return empty_in_place_factory();
}

template<typename T>
class empty_typed_in_place_factory : public typed_in_place_factory_base
{
public:
	typedef T value_type;

	empty_typed_in_place_factory()
	{
	}

	void apply(void* address) const
	{
		new(address) T;
	}
};

template<typename T>
empty_typed_in_place_factory<T> in_place()
{
	return empty_typed_in_place_factory<T>();
}

}

#endif

#if defined(BOOST_NO_RTTI)

template<typename T, typename U>
typename boost::enable_if<
	boost::mpl::and_<
		boost::is_polymorphic<T>,
		boost::is_polymorphic<U>
	>,
	bool
>::type
is_same_type(const T& a, const U& b)
{
	return *reinterpret_cast<void**>(&a) == *reinterpret_cast<void**>(&b);
}

#else

#include <typeinfo>

template<typename T, typename U>
typename boost::enable_if<
	boost::mpl::and_<
		boost::is_polymorphic<T>,
		boost::is_polymorphic<U>
	>,
	bool
>::type
is_same_type(const T& a, const U& b)
{
	return typeid(a) == typeid(b);
}

#endif


template<typename T, typename Base = void>
struct virtual_ctors : public Base
{
	virtual void clone(void* p) const
	{
		new(p) T(static_cast<const T&>(*this));
	}

	virtual std::pair<std::size_t, std::size_t> size_and_align() const
	{
		return std::make_pair(sizeof(T), boost::alignment_of<T>::value);
	}
};

template<typename T>
struct virtual_ctors<T>
{
	virtual void clone(void* p) const
	{
		new(p) T(static_cast<const T&>(*this));
	}

	virtual std::pair<std::size_t, std::size_t> size_and_align() const
	{
		return std::make_pair(sizeof(T), boost::alignment_of<T>::value);
	}
};

template<typename T>
class poly_obj
{
public:
	poly_obj()
	{
		obj = static_cast<T*>(::operator new(sizeof(T)));

		try
		{
			new(obj) T;
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	template<typename D>
	poly_obj(const D& d, typename boost::enable_if<boost::is_base_of<T, D> >::type* dummy = 0)
	{
		obj = static_cast<T*>(::operator new(d.size_and_align().first));

		try
		{
			d.clone(obj);
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	poly_obj(const poly_obj& p)
	{
		obj = static_cast<T*>(::operator new(p.get().size_and_align().first));

		try
		{
			p.get().clone(obj);
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	template<typename InPlaceFactory>
	poly_obj(const InPlaceFactory& f, typename boost::enable_if<boost::is_base_of<boost::in_place_factory_base, InPlaceFactory> >::type* dummy = 0)
	{
		obj = static_cast<T*>(::operator new(sizeof(T)));

		try
		{
			f.template apply<T>(obj);
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	template<typename TypedInPlaceFactory>
	poly_obj(const TypedInPlaceFactory& f, typename boost::enable_if<boost::is_base_of<boost::typed_in_place_factory_base, TypedInPlaceFactory> >::type* dummy = 0)
	{
		typedef typename TypedInPlaceFactory::value_type Type;

		obj = static_cast<T*>(::operator new(sizeof(Type)));

		try
		{
			f.apply(obj);
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	template<typename D>
	poly_obj(const poly_obj<D>& p, typename boost::enable_if<boost::is_base_of<T, D> >::type* dummy = 0)
	{
		obj = static_cast<T*>(::operator new(p.get().size_and_align().first));

		try
		{
			p.get().clone(obj);
		}
		catch(...)
		{
			::operator delete(obj);
			throw;
		}
	}

	template<typename D>
	typename boost::enable_if<
		boost::is_base_of<T, D>,
		poly_obj&
	>::type
	operator=(const D& d)
	{
		if(is_same_type(*obj, d))
		{
			*obj = d;
			return;
		}

		T* new_obj = static_cast<T*>(::operator new(d.size_and_align().first));

		try
		{
			d.clone(new_obj);
		}
		catch(...)
		{
			::operator delete(new_obj);
			throw;
		}


		obj->~T();
		::operator delete(obj);

		obj = new_obj;
	}

	template<typename D>
	typename boost::enable_if<
		boost::is_base_of<T, D>,
		poly_obj&
	>::type
	operator=(const poly_obj<D>& p)
	{
		if(is_same_type(*obj, p.get()))
		{
			*obj = p.get();
			return;
		}


		T* new_obj = static_cast<T*>(::operator new(p.get().size_and_align().first));

		try
		{
			p.get().clone(new_obj);
		}
		catch(...)
		{
			::operator delete(new_obj);
			throw;
		}


		obj->~T();
		::operator delete(obj);

		obj = new_obj;
	}

	template<typename InPlaceFactory>
	typename boost::enable_if<
		boost::is_base_of<boost::in_place_factory_base, InPlaceFactory>,
		poly_obj&
	>::type
	operator=(const InPlaceFactory& f)
	{
		T* new_obj = static_cast<T*>(::operator new(sizeof(T)));

		try
		{
			f.template apply<T>(new_obj);
		}
		catch(...)
		{
			::operator delete(new_obj);
			throw;
		}


		obj->~T();
		::operator delete(obj);

		obj = new_obj;
	}

	template<typename TypedInPlaceFactory>
	typename boost::enable_if<
		boost::is_base_of<boost::typed_in_place_factory_base, TypedInPlaceFactory>,
		poly_obj&
	>::type
	operator=(const TypedInPlaceFactory& f)
	{
		typedef typename TypedInPlaceFactory::value_type Type;

		T* new_obj = static_cast<T*>(::operator new(sizeof(Type)));

		try
		{
			f.apply(new_obj);
		}
		catch(...)
		{
			::operator delete(new_obj);
			throw;
		}


		obj->~T();
		::operator delete(obj);

		obj = new_obj;
	}

	~poly_obj()
	{
		obj->~T();
		::operator delete(obj);
	}

	T* operator->()
	{
		return obj;
	}

	const T* operator->() const
	{
		return obj;
	}

	operator T&()
	{
		return *obj;
	}

	operator const T&() const
	{
		return *obj;
	}

	T& get()
	{
		return *obj;
	}

	const T& get() const
	{
		return *obj;
	}

private:
	T* obj;
};

template<typename D, typename T>
poly_obj<D> dynamic_poly_cast(const poly_obj<T>& p)
{
	return poly_obj<D>(dynamic_cast<const D&>(p.get()));
}

template<typename D, typename T>
poly_obj<D> static_poly_cast(const poly_obj<T>& p)
{
	return poly_obj<D>(static_cast<const D&>(p.get()));
}



