// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// lockable.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef LOCKABLE_HPP_INCLUDED
#define LOCKABLE_HPP_INCLUDED

#include "interface.hpp"

// lockable class offers a wrapper that locks on every function call
template<typename T, typename L>
struct lockable;

// locked wrapper: lockable can be converted to locked, to have larger critical sections
template<typename T, typename L>
struct locked;

// details
namespace detail {
  template<typename T, typename L> 
  class locking_wrapper;
}

// define interface hook to interpose lock/unlock on every interface -> implementation method call
template<typename T, typename L>
struct interface_hook_type<T, lockable<T,L> > {
  typedef detail::locking_wrapper<T,L> type;
};

// implementation follows
namespace detail {
  // wrapper used internally by lockable
  template<typename T, typename L> 
  class locking_wrapper {
  public:
    // construct/copy/destruct
    locking_wrapper(T& v, L& l):ptr_(&v), lock_(&l) { lock_->lock(); }

    ~locking_wrapper() { lock_->unlock(); }

    operator T*() { return ptr_; }
    operator T const*() const { return ptr_; }

    T& operator *() { return *ptr_; }
    T const& operator *() const { return *ptr_; }

    T* operator ->() { return ptr_; }
    T const* operator ->() const { return ptr_; }

  private:
    T* ptr_;
    L* lock_;
  };

  struct null_lock {
    null_lock() {}
    void lock() {}
    void unlock() {}
    ~null_lock() {}

  private:
    bool locked;
  };

}

template<typename T, typename L>
struct lockable : interface<T, lockable<T,L> > {
  // types
  typedef T type;
  lockable() {}

  template<typename A>
  explicit lockable(A const& e):v_(e) {}

  operator locked<T,L>();

  using interface<T,lockable<T,L> >::operator=;

private:
  detail::locking_wrapper<T,L> get_() { return detail::locking_wrapper<T,L>(v_,l_); }
  detail::locking_wrapper<const T,L> get_() const { return detail::locking_wrapper<const T,L>(v_,l_); }

  friend class interface<T,lockable<T,L> >;
  friend class interface<const T,lockable<T,L> >;

  T v_;
  mutable L l_;
};

template<typename T, typename L>
struct locked : lockable<T,detail::null_lock> {
  // construct/copy/destruct
  locked(T& v, L& l):lockable<T,detail::null_lock>(v), lock_(&l) { lock_->lock(); }
  ~locked() { lock_->unlock(); }
private:
  L * lock_;
};

template<typename T, typename L>
inline lockable<T,L>::operator locked<T,L>() {
  return locked<T,L>(v_,l_);
}
#endif
