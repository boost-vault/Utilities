// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// interface.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef INTERFACE_HPP
#define INTERFACE_HPP
#include <boost/type_traits/is_fundamental.hpp>

// interface template class. Must be (partially) specialized for user types
template<typename T, typename W, typename B, bool stop_const_propagation>
struct interface;

// hook that can be used by wrappers to have special handling of what's returned by the get_ method
template<typename T, typename W>
struct interface_hook_type;

// empty struct to stop base class chain
struct unit {};

// default return type for get_ is T*
template<typename T, typename W>
struct interface_hook_type {
  typedef T * type;
};

// default interface (mutable): inherits from const interface
template<typename T, typename W, typename B=unit, bool stop_const_propagation=false>
struct interface : interface<const T, W, B> {
  typedef T type;
  type& operator=(const type& o) { *get_()=o; }

private:
  typename interface_hook_type<type,W>::type
  get_() { return static_cast<W*>(this)->get_(); }
};

template<typename T, typename W, typename B>
struct interface<T,W,B,true> : interface<const T, W, B> {
  typedef T type;
  type& operator=(const type& o) const { *get_()=o; }

private:
  typename interface_hook_type<type,W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

// default interface (const)
template<typename T, typename W, typename B>
struct interface <const T, W, B> : B {
  typedef const T type;

private:
  typename interface_hook_type<type,W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};
#endif
