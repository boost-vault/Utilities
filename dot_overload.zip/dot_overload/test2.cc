// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test2.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "string_interface.hpp"
#include "wrappers.hpp"
#include <iostream>

int main() {
  value_wrapper<std::string> h("Hello");
  value_wrapper<std::string> w("World");
  std::cout<<h+" "+w<<"\n";
  std::cout<<h+w<<"\n";

  std::string a="Hello World";
  std::string a1="Wow";
  reference_wrapper<std::string> b(a);
  value_wrapper<std::string> c(a);

  reference_wrapper<const std::string> b1(a);
  value_wrapper<const std::string> c1(a);

  const reference_wrapper<std::string> b2(a);
  const value_wrapper<std::string> c2(a);
  size_t z0= b.size()+c.size();
  size_t z1= b1.size()+c1.size();
  size_t z2= b2.size()+c2.size();

  // ok:
  b=a1; 
  b.swap(a1);
  b1=b1;

  // fail:
  //b1=a1;
  //b1.swap(a1);
  //b2=b2;

  // it works:
  b2=a1;
  b2.swap(a1);

  // ok:
  c=a1;
  c.swap(a1);

  // fail:
  //c1=a1;
  //c1=c1;
  //c1.swap(a1);
  //c2=a1;
  //c2=c2;
  //c2.swap(a1);
  return z0+z1+z2;
}
