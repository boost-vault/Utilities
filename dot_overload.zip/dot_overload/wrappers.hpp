// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// wrappers.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef WRAPPERS_HPP_INCLUDED
#define WRAPPERS_HPP_INCLUDED

#include "interface.hpp"

// interface enabled reference wrapper
template<typename T> 
class reference_wrapper : public interface<T,reference_wrapper<T>, unit, true > {
public:
  // types
  typedef T type;

  // construct/copy/destruct
  explicit reference_wrapper(T& v):ptr_(&v) {}

  // access
  operator type&() const    { return *ptr_; }

  using interface<T,reference_wrapper<T>, unit, true >::operator=;
private:
  T* get_() { return ptr_; }
  T* get_() const { return ptr_; }

  friend class interface<T,reference_wrapper<T>, unit, true >;
  friend class interface<const T,reference_wrapper<T>, unit>;

  T* ptr_;
};


// interface enabled value wrapper
template<typename T> 
class value_wrapper : public interface<T,value_wrapper<T> > {
public:
  // types
  typedef T type;

  // construct/copy/destruct
  explicit value_wrapper(T const& v):ptr_(v) {}

  operator type const&() const { return *get_(); }
  operator type&()             { return *get_(); }

  using interface<T,value_wrapper<T> >::operator=;
private:
  T* get_() { return &ptr_; }
  T const* get_() const { return &ptr_; }

  friend class interface<T,value_wrapper<T> >;
  friend class interface<const T,value_wrapper<T> >;

  T ptr_;
};

// type erasure wrapper, made possible by the interface machinery
template<typename I, typename T>
struct type_erasure_wrapper : interface<T,type_erasure_wrapper<I,T>, I> {
  // types
  typedef T type;
  typedef interface<T,type_erasure_wrapper<I,T>, I> interface_type;

  // construct/copy/destruct
  explicit type_erasure_wrapper(T const& v):val_(v) {}

  operator type const&() const { return *get_(); }
  operator type&()             { return *get_(); }

  using interface_type::operator=;
private:
  T* get_() { return &val_; }
  T const* get_() const { return &val_; }

  friend class interface<T,type_erasure_wrapper<I,T>, I>;
  friend class interface<const T,type_erasure_wrapper<I,T>, I>;

  T val_;
};

#include<boost/function.hpp>
// interface enabled computation wrapper
template<typename T, bool no_const_propagation=false> 
class computation_wrapper : public interface<T,computation_wrapper<T>, unit, no_const_propagation > {
public:
  // types
  typedef T type;

  // construct/copy/destruct
  template<typename F>
  explicit computation_wrapper(F c):fun_(c) {}

  operator type const&() const { return *get_(); }
  operator type&()             { return *get_(); }

  using interface<T,computation_wrapper<T>, unit, no_const_propagation >::operator=;

private:
  T* get_() { return &(fun_()); }
  T const* get_() const { return &(fun_()); }

  friend class interface<T,computation_wrapper<T>, unit, no_const_propagation >;
  friend class interface<const T,computation_wrapper<T>, unit>;
  boost::function<T& ()> const fun_;
};

template<typename T>
class computation_wrapper<T,true> : public interface<T,computation_wrapper<T, true>, unit, true > {
public:
  // types
  typedef T type;

  // construct/copy/destruct
  template<typename F>
  explicit computation_wrapper(F c):fun_(c) {}

  operator type&() const { return *get_(); }

  using interface<T,computation_wrapper<T, true>, unit, true >::operator=;

private:
  T* get_() { return &(fun_()); }
  T* get_() const { return &(fun_()); }

  friend class interface<T,computation_wrapper<T, true>, unit, true >;
  friend class interface<const T,computation_wrapper<T, true>, unit>;
  boost::function<T& ()> const fun_;
};
#endif
