// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test1.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "my_struct.hpp"
#include "lockable.hpp"

#include <cassert>
#include <iostream>

struct debug_lock {
  debug_lock() : locked() {}
  void lock() { assert(!locked); locked=true; std::cerr<<"locking\n"; }
  void unlock() { assert(locked); locked=false; std::cerr<<"unlocking\n"; }
  ~debug_lock() { assert(!locked); }
private:
  bool locked;
};

int main() {
  lockable<my_struct, debug_lock> ms;
  ms.set(1);
  ms.set(2);
  {
    locked<my_struct,debug_lock> m_=ms;
    m_.set(3);
    m_.set(4);
  }

  return 0;
}
