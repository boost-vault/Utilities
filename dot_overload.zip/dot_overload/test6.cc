// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test2.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "wrappers.hpp"
#include "pair_interface.hpp"
#include <iostream>

int main() {
  typedef std::pair<int,float> my_pair;

  my_pair ts(1,0.5);
  reference_wrapper<my_pair> b(ts);
  value_wrapper<my_pair> c(ts);

  reference_wrapper<const my_pair> b1(ts);
  value_wrapper<const my_pair> c1(ts);

  const reference_wrapper<my_pair> b2(ts);
  const value_wrapper<my_pair> c2(ts);

  // b1.first=2; // error
  b2.first=2;

  std::cout<< ts.first << ' ' << ts.second << '\n';
  std::cout<<  b.first << ' ' <<  b.second << '\n';
  std::cout<< b1.first << ' ' << b1.second << '\n';
  std::cout<< b2.first << ' ' << b2.second << '\n';

  std::cout<<  c.first << ' ' <<  c.second << '\n';
  std::cout<< c1.first << ' ' << c1.second << '\n';
  std::cout<< c2.first << ' ' << c2.second << '\n';
  return 0;
}
