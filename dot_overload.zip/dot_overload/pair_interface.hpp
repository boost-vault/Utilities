// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// string_interface.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef PAIR_INTERFACE_HPP_INCLUDED
#define PAIR_INTERFACE_HPP_INCLUDED
#include "interface.hpp"
# include <utility>
# include "wrappers.hpp"
# include <boost/bind.hpp>

// sample (const) interface for std::pair
template<typename T1, typename T2, typename W, typename B>
struct interface<const std::pair<T1,T2>, W, B> : B {
  typedef const std::pair<T1,T2> type;

  computation_wrapper<T1 const> const first;
  computation_wrapper<T2 const> const second;

  interface(): first (boost::bind<T1 const&>( &type::first,  boost::bind(&interface::get_,this))),
	       second(boost::bind<T2 const&>( &type::second, boost::bind(&interface::get_,this))) 
  {}
private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

// sample (mutable) interface for std::pair
template<typename T1, typename T2, typename W, typename B>
struct interface<std::pair<T1,T2>, W, B, false> : interface<const std::pair<T1,T2>, W, B> {
  typedef std::pair<T1,T2> type;

  void swap(type& other) { get_()->swap(other); }
  type& operator=(type other) { get_()->swap(other); return *get_(); }

  computation_wrapper<T1> first;
  computation_wrapper<T2> second;

  interface(): first (boost::bind<T1&>( &type::first,  boost::bind(&interface::get_,this))),
	       second(boost::bind<T2&>( &type::second, boost::bind(&interface::get_,this))) 
  {}

private:
  typename interface_hook_type<type, W>::type
  get_() { return static_cast<W*>(this)->get_(); }
};

template<typename T1, typename T2, typename W, typename B>
struct interface<std::pair<T1,T2>, W, B, true> : interface<const std::pair<T1,T2>, W, B> {
  typedef std::pair<T1,T2> type;

  void swap(type& other) const { get_()->swap(other); }
  type& operator=(type other) const { get_()->swap(other); return *get_(); }

  computation_wrapper<T1,true> const first;
  computation_wrapper<T2,true> const second;

  interface(): first (boost::bind<T1&>( &type::first,  boost::bind(&interface::get_,this))),
	       second(boost::bind<T2&>( &type::second, boost::bind(&interface::get_,this))) 
  {}

private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

#endif
