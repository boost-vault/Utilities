// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test2.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "wrappers.hpp"
#include <iostream>

int& some_fun() { static int i=0; return ++i; }

int main() {
  const computation_wrapper<int> w(some_fun);
  std::cout<<w<<"\n";
  std::cout<<w<<"\n";
  std::cout<<w<<"\n";
  //w=7; // error

  const computation_wrapper<int,true> w1(some_fun); // no const propagation
  w1=7;
  std::cout<<w<<"\n";
  std::cout<<w<<"\n";
  std::cout<<w<<"\n";
  return w1+2;
}
