// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test3.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "string_interface.hpp"
#include "wrappers.hpp"
#include <iostream>

struct string_virtual_interface {
  virtual std::size_t size() const=0;
  virtual const char * c_str() const=0;
};

void example(string_virtual_interface * i) {
  std::cout<<"size= "<<i->size()<<"\ncontent: "<<i->c_str()<<"\n";
}

struct my_string {
  my_string():v(),sz() {}
  my_string(const char *v):v(v),sz(strlen(v)) {}
  my_string(const char *v, size_t sz):v(v),sz(sz) {}
  size_t size() const { return sz; }
  const char * c_str() const { return v; }
private:
  const char * v;
  size_t sz;
};

template<typename W, typename B>
struct interface<const my_string, W, B> : B {
  typedef const my_string type;

  std::size_t size() const { return get_()->size(); }
  const char * c_str() const { return get_()->c_str(); }
private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

int main() {
  type_erasure_wrapper<string_virtual_interface, std::string> h("Hello");
  type_erasure_wrapper<string_virtual_interface, my_string> w("World!");
  example(&h);
  example(&w);
  return 0;
}
