// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// test2.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "wrappers.hpp"
#include <iostream>

struct test_struct {
  void non_const_method() { std::cout<<"non_const_method called on "<<this<<std::endl; }
};

template<typename W, typename B>
struct interface<test_struct, W, B, true > : interface<const test_struct, W, B> {
  typedef test_struct type;

  void non_const_method() const { get_()->non_const_method(); }

private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

template<typename W, typename B>
struct interface<test_struct, W, B, false> : interface<const test_struct, W, B> {
  typedef test_struct type;

  void non_const_method() { get_()->non_const_method(); }

private:
  typename interface_hook_type<type, W>::type
  get_() { return static_cast<W*>(this)->get_(); }
};


int main() {
  test_struct ts;
  reference_wrapper<test_struct> b(ts);
  value_wrapper<test_struct> c(ts);

  reference_wrapper<const test_struct> b1(ts);
  value_wrapper<const test_struct> c1(ts);

  const reference_wrapper<test_struct> b2(ts);
  const value_wrapper<test_struct> c2(ts);

  b.non_const_method();
  c.non_const_method();
  b2.non_const_method();

  // error
  //b1.non_const_method();
  //c1.non_const_method();
  //c2.non_const_method();
  return 0;
}
