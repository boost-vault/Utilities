// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// string_interface.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef STRING_INTERFACE_HPP_INCLUDED
#define STRING_INTERFACE_HPP_INCLUDED
#include "interface.hpp"
# include <string>
// sample (const) interface for std::string
template<typename W, typename B>
struct interface<const std::string, W, B> : B {
  typedef const std::string type;

  std::size_t size() const { return get_()->size(); }
  const char * c_str() const { return get_()->c_str(); }

  // free operators as friend
  template<typename W1, typename B1> friend
  std::string operator+ (const interface<const std::string,W,B>& lhs, const interface<const std::string,W1,B1>& rhs)
  { return *lhs.get_()+*rhs.get_(); }
  friend
  std::string operator+ (const interface<const std::string,W,B>& lhs, const std::string& rhs)
  { return *lhs.get_()+rhs; }
  friend
  std::string operator+ (const std::string& lhs, const interface<const std::string,W,B>& rhs)
  { return lhs+*rhs.get_(); }
  friend
  std::string operator+ (const char* lhs, const interface<const std::string,W,B>& rhs)
  { return lhs+*rhs.get_(); }
  friend
  std::string operator+ (char lhs, const interface<const std::string,W,B>& rhs)
  { return lhs+*rhs.get_(); }
  friend
  std::string operator+ (const interface<const std::string,W,B>& lhs, const char* rhs)
  { return *lhs.get_()+rhs; }
  friend
  std::string operator+ (const interface<const std::string,W,B>& lhs, char rhs)
  { return *lhs.get_()+rhs; }

private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

// sample (mutable) interface for std::string
template<typename W, typename B>
struct interface<std::string, W, B, false> : interface<const std::string, W, B> {
  typedef std::string type;

  void swap(std::string& other) { get_()->swap(other); }
  std::string& operator=(std::string other) { get_()->swap(other); return *get_(); }

  std::string& append ( const std::string& str ) { return get_()->append(str); }
  std::string& append ( const std::string& str, size_t pos, size_t n ) { return get_()->append(str,pos,n); }
  std::string& append ( const char* s, size_t n ) { return get_()->append(s,n); }
  std::string& append ( const char* s ) { return get_()->append(s); }
  std::string& append ( size_t n, char c ) { return get_()->append(n,c); }
  template <class InputIterator>
  std::string& append ( InputIterator first, InputIterator last ) { return get_()->append(first,last); }

private:
  typename interface_hook_type<type, W>::type
  get_() { return static_cast<W*>(this)->get_(); }
};

template<typename W, typename B>
struct interface<std::string, W, B, true> : interface<const std::string, W, B> {
  typedef std::string type;

  void swap(std::string& other) const { get_()->swap(other); }
  std::string& operator=(std::string other) const { get_()->swap(other); return *get_(); }

  std::string& append ( const std::string& str ) const { return get_()->append(str); }
  std::string& append ( const std::string& str, size_t pos, size_t n ) const { return get_()->append(str,pos,n); }
  std::string& append ( const char* s, size_t n ) const { return get_()->append(s,n); }
  std::string& append ( const char* s ) const { return get_()->append(s); }
  std::string& append ( size_t n, char c ) const { return get_()->append(n,c); }
  template <class InputIterator>
  std::string& append ( InputIterator first, InputIterator last ) const { return get_()->append(first,last); }

private:
  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }
};

#endif
