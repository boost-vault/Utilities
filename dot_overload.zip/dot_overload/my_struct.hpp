// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// my_struct.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef MY_STRUCT_HPP_INCLUDED
#define MY_STRUCT_HPP_INCLUDED
#include "interface.hpp"
#include <iostream>

struct my_struct {
  void set(int i) { std::cerr<<"value set to "<<i<<"\n"; }
};

// sample (mutable) interface for std::string
template<typename W, typename B>
struct interface<my_struct, W, B> : interface<const my_struct, W, B> {
  typedef my_struct type;

  void set(int i) { get_()->set(i); }

private:
  typename interface_hook_type<type, W>::type
  get_() { return static_cast<W*>(this)->get_(); }

  typename interface_hook_type<type, W>::type
  get_() const { return static_cast<W const*>(this)->get_(); }  
};
#endif
